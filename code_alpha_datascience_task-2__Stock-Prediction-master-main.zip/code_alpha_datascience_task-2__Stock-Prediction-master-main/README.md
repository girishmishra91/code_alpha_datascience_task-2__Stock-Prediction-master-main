# code_alpha_datascience_task-2__Stock-Prediction-master
Take stock price of any company you want and predicts  its price by using LSTM. Use only Jupyter notebook  code
